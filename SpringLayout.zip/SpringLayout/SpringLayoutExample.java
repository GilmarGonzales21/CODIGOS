import javax.swing.*;
import java.awt.Container;

public class SpringLayoutExample {
    public static void main(String[] args) {
        // Crear el JFrame
        JFrame frame = new JFrame("SpringLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Crear el contenedor principal
        Container contentPane = frame.getContentPane();

        // Crear el SpringLayout
        SpringLayout layout = new SpringLayout();
        contentPane.setLayout(layout);

        // Crear dos botones
        JButton button1 = new JButton("Button 1");
        JButton button2 = new JButton("Button 2");

        // Añadir los botones al contenedor
        contentPane.add(button1);
        contentPane.add(button2);

        // Definir las restricciones para button1
        layout.putConstraint(SpringLayout.WEST, button1, 20, SpringLayout.WEST, contentPane);
        layout.putConstraint(SpringLayout.NORTH, button1, 20, SpringLayout.NORTH, contentPane);

        // Definir las restricciones para button2
        layout.putConstraint(SpringLayout.WEST, button2, 20, SpringLayout.WEST, contentPane);
        layout.putConstraint(SpringLayout.NORTH, button2, 20, SpringLayout.SOUTH, button1);

        // Hacer visible el frame
        frame.setVisible(true);
    }
}


